import { Component, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ExpenseService } from 'src/app/services/expense.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})
export class DashboardComponent {
  expenseForm!: FormGroup;
  editForm!: FormGroup;
  expenses: any[] = [];

  submitted = false;
  editSubmitted = false;

  showOtherCategoryAdd = false;
  showOtherCategoryEdit = false;

  currentEditingId: string = '';
  defaultCategories = ['Food', 'Transport', 'Bills', 'Entertainment', 'Health'];

  @ViewChild('editModal') editModal: any;

  constructor(
    private fb: FormBuilder,
    private dashboardService: ExpenseService,
    private modalService: NgbModal,
    private commonService: CommonService
  ) {}

  ngOnInit(): void {
    this.initForms();
    this.getExpenses();
  }

  initForms() {
    this.expenseForm = this.fb.group({
      title: ['', Validators.required],
      category: ['', Validators.required],
      otherCategory: [''],
      amount: ['', [Validators.required, Validators.min(1)]],
      date: ['', Validators.required],
    });

    this.editForm = this.fb.group({
      title: ['', Validators.required],
      category: ['', Validators.required],
      otherCategory: [''],
      amount: ['', [Validators.required, Validators.min(1)]],
      date: ['', Validators.required],
    });
  }

  get form() {
    return this.expenseForm.controls;
  }

  get edit() {
    return this.editForm.controls;
  }

  onCategoryChange(formType: 'add' | 'edit') {
    if (formType === 'add') {
      const category = this.form['category'].value;
      this.showOtherCategoryAdd = category === 'Other';
      if (this.showOtherCategoryAdd) {
        this.form['otherCategory'].setValidators(Validators.required);
      } else {
        this.form['otherCategory'].clearValidators();
        this.form['otherCategory'].setValue('');
      }
      this.form['otherCategory'].updateValueAndValidity();
    } else {
      const category = this.edit['category'].value;
      this.showOtherCategoryEdit = category === 'Other';
      if (this.showOtherCategoryEdit) {
        this.edit['otherCategory'].setValidators(Validators.required);
      } else {
        this.edit['otherCategory'].clearValidators();
        this.edit['otherCategory'].setValue('');
      }
      this.edit['otherCategory'].updateValueAndValidity();
    }
  }

  submitExpense() {
    this.submitted = true;
    if (this.expenseForm.invalid) return;

    const payload = {
      ...this.expenseForm.value,
      category:
        this.expenseForm.value.category === 'Other'
          ? this.expenseForm.value.otherCategory
          : this.expenseForm.value.category,
    };

    this.commonService.showLoader();
    this.dashboardService.addExpense(payload).subscribe({
      next: () => {
        this.expenseForm.reset();
        this.submitted = false;
        this.showOtherCategoryAdd = false;
        this.getExpenses();
        this.commonService.hideLoader();
      },
      error: () => this.commonService.hideLoader(),
    });
  }

  clearForm() {
    this.expenseForm.reset();
    this.submitted = false;
    this.showOtherCategoryAdd = false;

    Object.keys(this.expenseForm.controls).forEach((field) => {
      const control = this.expenseForm.get(field);
      control?.setErrors(null);
    });
  }

  getExpenses() {
    this.commonService.showLoader();
    this.dashboardService.getExpenses().subscribe({
      next: (res) => {
        this.expenses = res;
        this.commonService.hideLoader();
      },
      error: () => this.commonService.hideLoader(),
    });
  }

  deleteExpense(id: string) {
    if (!confirm('Are you sure to delete this expense?')) return;
    this.commonService.showLoader();
    this.dashboardService.deleteExpense(id).subscribe({
      next: () => {
        this.getExpenses();
        this.commonService.hideLoader();
      },
      error: () => this.commonService.hideLoader(),
    });
  }

  openEditModal(expense: any) {
    this.currentEditingId = expense._id;
    const isOther = !this.defaultCategories.includes(expense.category);

    this.editForm.patchValue({
      title: expense.title,
      category: isOther ? 'Other' : expense.category,
      otherCategory: isOther ? expense.category : '',
      amount: expense.amount,
      date: expense.date?.substring(0, 10),
    });

    this.showOtherCategoryEdit = isOther;
    this.editSubmitted = false;

    this.modalService.open(this.editModal, { centered: true });
  }

  updateExpense() {
    this.editSubmitted = true;
    if (this.editForm.invalid) return;

    const updatedData = {
      ...this.editForm.value,
      category:
        this.editForm.value.category === 'Other'
          ? this.editForm.value.otherCategory
          : this.editForm.value.category,
    };

    this.commonService.showLoader();
    this.dashboardService
      .updateExpense(this.currentEditingId, updatedData)
      .subscribe({
        next: () => {
          this.modalService.dismissAll();
          this.getExpenses();
          this.commonService.hideLoader();
        },
        error: () => this.commonService.hideLoader(),
      });
  }
}
