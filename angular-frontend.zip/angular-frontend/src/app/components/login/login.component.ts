import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html'
})
export class LoginComponent {
  loginForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private router: Router
  ) {
    this.loginForm = this.fb.group({
      email: [''],
      password: ['']
    });
  }

  ngOnInit(): void {
    if (localStorage.getItem('token')) {
      this.router.navigate(['/dashboard']);
    }
  }

  onSubmit() {
    this.auth.login(this.loginForm.value).subscribe({
      next: (res) => {
        this.auth.storeToken(res.token);
        this.router.navigate(['/dashboard']);
      },
      error: (err) => alert('Login failed: ' + err.error?.error || 'Unknown error')
    });
  }
}
