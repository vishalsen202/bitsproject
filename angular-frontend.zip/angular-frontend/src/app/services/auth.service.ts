import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { finalize, Observable } from 'rxjs';
import { CommonService } from './common.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  
  private apiUrl = 'http://localhost:5000/api/auth';

  constructor(private http: HttpClient, private loader: CommonService, private router: Router) {}

  login(data: any): Observable<any> {
    this.loader.showLoader();
    return new Observable(observer => {
      this.http.post(`${this.apiUrl}/login`, data).subscribe({
        next: res => {
          this.loader.hideLoader();
          observer.next(res);
          observer.complete();
        },
        error: err => {
          this.loader.hideLoader();
          observer.error(err);
        }
      });
    });
  }

  register(data: any): Observable<any> {
    this.loader.showLoader();
    return new Observable(observer => {
      this.http.post(`${this.apiUrl}/register`, data).subscribe({
        next: res => {
          this.loader.hideLoader();
          observer.next(res);
          observer.complete();
        },
        error: err => {
          this.loader.hideLoader();
          observer.error(err);
        }
      });
    });
  }

  storeToken(token: string) {
    localStorage.setItem('token', token);
  }
}
