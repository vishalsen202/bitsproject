const Expense = require('../models/Expense');

// Get all expenses for the logged-in user
exports.getExpenses = async (req, res) => {
  try {
    const expenses = await Expense.find({ user: req.user.id });
    res.json(expenses);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
};

// Add a new expense
exports.addExpense = async (req, res) => {
  try {
    const { title, amount, category } = req.body;
    const expense = new Expense({
      user: req.user.id,
      title,
      amount,
      category
    });
    await expense.save();
    res.status(201).json(expense);
  } catch (err) {
    res.status(400).json({ error: 'Failed to add expense' });
  }
};

// Delete an expense by ID
exports.deleteExpense = async (req, res) => {
  try {
    const result = await Expense.findByIdAndDelete(req.params.id);
    if (!result) return res.status(404).json({ error: 'Expense not found' });
    res.json({ message: 'Expense deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Delete failed' });
  }
};

// Update an expense by ID
exports.updateExpense = async (req, res) => {
  try {
    const { title, amount, category, date } = req.body;
    const expense = await Expense.findById(req.params.id);

    if (!expense) {
      return res.status(404).json({ error: 'Expense not found' });
    }

    if (expense.user.toString() !== req.user.id) {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    expense.title = title;
    expense.amount = amount;
    expense.category = category;
    expense.date = date;

    await expense.save();
    res.json(expense);
  } catch (err) {
    console.error('Update error:', err);
    res.status(500).json({ error: 'Failed to update expense' });
  }
};